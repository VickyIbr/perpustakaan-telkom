<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="container my-4">

    
    <div class="card mb-4">
        <div class="card-body d-flex justify-content-between align-items-center">
            <div>
                <h4 class="mb-1">Dashboard Buku</h4>
                <small class="text-muted">Ringkasan data buku di sistem</small>
            </div>

            <?php if(Auth::user()->role == 'admin'): ?>
                <a href="<?php echo e(route('books.create')); ?>" class="btn btn-primary btn-sm">
                    + Tambah Buku
                </a>
            <?php endif; ?>
        </div>
    </div>

    
    <div class="card">
        <div class="card-body p-0">
            <table class="table table-hover mb-0 align-middle">
                <thead class="table-light">
                    <tr>
                        <th>Judul</th>
                        <th>Penulis</th>
                        <th>Penerbit</th>
                        <th>Tahun</th>
                        <th class="text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($book->title); ?></td>
                            <td><?php echo e($book->author); ?></td>
                            <td><?php echo e($book->publisher); ?></td>
                            <td><?php echo e($book->year); ?></td>
                            <td class="text-center">

                                <?php if(Auth::user()->role == 'admin'): ?>
                                    <a href="<?php echo e(route('books.edit', $book->id)); ?>"
                                        class="btn btn-warning btn-sm">
                                        Edit
                                    </a>

                                    <form action="<?php echo e(route('books.destroy', $book->id)); ?>"
                                        method="POST" class="d-inline"
                                        onsubmit="return confirm('Yakin ingin menghapus buku ini?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button class="btn btn-danger btn-sm">
                                            Hapus
                                        </button>
                                    </form>
                                <?php else: ?>
                                    <?php if(!$book->is_borrowed): ?>
                                        <form method="POST"
                                            action="<?php echo e(route('transactions.borrow', $book->id)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <button class="btn btn-success btn-sm">
                                                Pinjam
                                            </button>
                                        </form>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">
                                            Tidak Tersedia
                                        </span>
                                    <?php endif; ?>
                                <?php endif; ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="text-center text-muted py-4">
                                Tidak ada data buku
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Workspace\USK\perpustakaan-telkom\resources\views\books\index.blade.php ENDPATH**/ ?>