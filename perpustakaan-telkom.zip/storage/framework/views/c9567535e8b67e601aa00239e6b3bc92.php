<?php $__env->startSection('title', 'Dashboard Transaksi'); ?>

<?php $__env->startSection('content'); ?>
<div class="container my-4">

    
    <div class="card mb-4">
        <div class="card-body d-flex justify-content-between align-items-center">
            <div>
                <h4 class="mb-1">Dashboard Transaksi</h4>
                <small class="text-muted">Data peminjaman & pengembalian buku</small>
            </div>

            <?php if(Auth::user()->role == 'admin'): ?>
                <a href="<?php echo e(route('transactions.create')); ?>" class="btn btn-primary btn-sm">
                    Tambah Transaksi
                </a>
            <?php endif; ?>
        </div>
    </div>

    
    <div class="card">
        <div class="card-body p-0">
            <table class="table table-hover mb-0 align-middle">
                <thead class="table-light">
                    <tr>
                        <th>Kode Buku</th>
                        <th>Judul Buku</th>
                        <?php if(Auth::user()->role == 'admin'): ?>
                            <th>Peminjam</th>
                        <?php endif; ?>
                        <th>Tgl Pinjam</th>
                        <th>Tgl Kembali</th>
                        <th class="text-center">Status</th>
                        <th class="text-center">Aksi</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            
                            <td><?php echo e($transaction->book->book_code); ?></td>
                            <td><?php echo e($transaction->book->title); ?></td>

                            
                            <?php if(Auth::user()->role == 'admin'): ?>
                                <td><?php echo e($transaction->user->name); ?></td>
                            <?php endif; ?>

                            
                            <td><?php echo e($transaction->borrowed_at->format('d M Y')); ?></td>
                            <td>
                                <?php echo e($transaction->returned_at
                                    ? $transaction->returned_at->format('d M Y')
                                    : '-'); ?>

                            </td>

                            
                            <td class="text-center">
                                <?php if($transaction->status === 'borrowed'): ?>
                                    <span class="badge bg-warning text-dark">
                                        Dipinjam
                                    </span>
                                <?php else: ?>
                                    <span class="badge bg-success">
                                        Dikembalikan
                                    </span>
                                <?php endif; ?>
                            </td>

                            
                            <td class="text-center">
                                <?php if($transaction->status === 'borrowed'): ?>
                                    <form action="<?php echo e(route('transactions.return', $transaction->id)); ?>"
                                        method="POST" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <button class="btn btn-sm btn-primary">
                                            Kembalikan
                                        </button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="text-center text-muted py-4">
                                Tidak ada data transaksi
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Workspace\USK\perpustakaan-telkom\resources\views\transactions\index.blade.php ENDPATH**/ ?>