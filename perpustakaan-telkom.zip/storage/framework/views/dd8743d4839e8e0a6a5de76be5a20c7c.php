<nav class="navbar navbar-expand-lg navbar-light bg-white border-bottom">
    <div class="container">

        
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarMenu">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarMenu">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">

                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->routeIs('books.*') ? 'active fw-semibold' : ''); ?>"
                        href="<?php echo e(route('books.index')); ?>">
                        Buku
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->routeIs('transactions.*') ? 'active fw-semibold' : ''); ?>"
                        href="<?php echo e(route('transactions.index')); ?>">
                        Transaksi
                    </a>
                </li>

                <?php if(Auth::user()->role == 'admin'): ?>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('users.*') ? 'active fw-semibold' : ''); ?>"
                            href="<?php echo e(route('users.index')); ?>">
                            Kelola Anggota
                        </a>
                    </li>
                <?php endif; ?>
            </ul>

            
            <div class="d-flex align-items-center gap-3">

                <div class="d-none d-lg-block">
                    <div class="fw-semibold"><?php echo e(Auth::user()->name); ?></div>
                    <div class="text-muted small">
                        <?php echo e(Auth::user()->role == 'admin' ? 'Administrator' : Auth::user()->major . ' - ' . Auth::user()->class); ?>

                    </div>
                </div>

                
                <form action="<?php echo e(route('logout')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-dark btn-sm">
                        Logout
                    </button>
                </form>
            </div>
        </div>
    </div>
</nav>
<?php /**PATH D:\Workspace\USK\perpustakaan-telkom\resources\views\layouts\navbar.blade.php ENDPATH**/ ?>